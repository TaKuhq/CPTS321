﻿//-----------------------------------------------------------------------
// <copyright file="TestClass.cs" company="My company">
// Class: CPTS321
// HW4:First Steps for your Spreadsheet Application
// Name:Hongqi Guo
// ID: 011552159
// NUnit 3 tests
// See documentation : https://github.com/nunit/docs/wiki/NUnit-Documentation
// </copyright>
//-----------------------------------------------------------------------
namespace NUnit.TestsHW4
{
    using System.Collections;
    using System.Collections.Generic;
    using NUnit.Framework;

    /// <summary>
    /// Test cases, five in all.
    /// </summary>
    [TestFixture]
    public class TestClass
    {
        /// <summary>
        /// I don't know what I need to test.
        /// </summary>
        [Test]
        public void TestMethod()
        {
            // TODO: Add your test code here
            var answer = 42;
            Assert.That(answer, Is.EqualTo(42), "Some useful error message");
        }
    }
}
