﻿//-----------------------------------------------------------------------
// <copyright file="Form1.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace HW7_Spreadsheet
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows.Forms;
    using CptS321;

    /// <summary>
    /// Class declarations.
    /// </summary>
    public partial class Form1 : Form
    {
        /// <summary>
        /// Initialize the data in sheet.
        /// </summary>
        private readonly Spreadsheet mySheet = new Spreadsheet(50, 26);

        /// <summary>
        /// Initializes a new instance of the <see cref="Form1"/> class.
        /// </summary>
        public Form1()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// cell begin edit function..
        /// </summary>
        /// <param name="sender">The parameter is not used. </param>
        /// <param name="e">The parameter is not used. </param>
        public void CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            int row = e.RowIndex, column = e.ColumnIndex;

            Cell spreadsheetCell = this.mySheet.GetCell(row, column);

            this.dataGrid.Rows[row].Cells[column].Value = spreadsheetCell.Text;
        }

        /// <summary>
        /// cell end edit function.
        /// </summary>
        /// <param name="sender">The parameter is not used. </param>
        /// <param name="e">The parameter is not used. </param>
        public void CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            int row = e.RowIndex, column = e.ColumnIndex;
            string myText;

            Cell spreadsheetCell = this.mySheet.GetCell(row, column);

            try
            {
                myText = this.dataGrid.Rows[row].Cells[column].Value.ToString();
            }
            catch (NullReferenceException)
            {
                myText = string.Empty;
            }

            spreadsheetCell.Text = myText;

            this.dataGrid.Rows[row].Cells[column].Value = spreadsheetCell.Value;
        }

        /// <summary>
        /// setup the columns,rows and resize the row headers.
        /// </summary>
        /// <param name="sender">The parameter is not used. </param>
        /// <param name="e">The parameter is not used. </param>
        private void Form1_Load(object sender, EventArgs e)
        {
            this.mySheet.CellPropertyChanged += this.OnCellPropertyChanged;
            this.dataGrid.CellBeginEdit += this.CellBeginEdit;
            this.dataGrid.CellEndEdit += this.CellEndEdit;

            this.dataGrid.Columns.Clear();
            string letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            for (int i = 0; i <= 25; i++)
            {
                this.dataGrid.Columns.Add(letters[i].ToString(), letters[i].ToString());
            }

            this.dataGrid.Rows.Add(50);
            for (int i = 0; i < 50; i++)
            {
                var row = this.dataGrid.Rows[i];
                row.HeaderCell.Value = (i + 1).ToString();
            }
        }

        /// <summary>
        /// on cell property change.
        /// </summary>
        /// <param name="sender">The parameter is not used. </param>
        /// <param name="e">The parameter is not used. </param>
        private void OnCellPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "Value" && sender is Cell selectedCell)
            {
                this.dataGrid.Rows[selectedCell.RowIndex].Cells[selectedCell.ColumnIndex].Value = selectedCell.Value;
            }
        }

        /// <summary>
        /// Nonsense operation.
        /// </summary>
        /// <param name="sender">Load File parameter.</param>
        /// <param name="e">The parameter is not used. </param>
        private void CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }
    }
}
