﻿// <copyright file="Form1.Designer.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>
namespace HW7_Spreadsheet
{
    /// <summary>
    /// Form1 Designer function.
    /// </summary>
    public partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Define the DataGridView system.
        /// </summary>
        private System.Windows.Forms.DataGridView dataGrid;

        /// <summary>
        /// Define the columnA.
        /// </summary>
        private System.Windows.Forms.DataGridViewTextBoxColumn columnA;

        /// <summary>
        /// Define the columnB.
        /// </summary>
        private System.Windows.Forms.DataGridViewTextBoxColumn columnB;

        /// <summary>
        /// Define the columnC.
        /// </summary>
        private System.Windows.Forms.DataGridViewTextBoxColumn columnC;

        /// <summary>
        /// Define the columnD.
        /// </summary>
        private System.Windows.Forms.DataGridViewTextBoxColumn columnD;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGrid = new System.Windows.Forms.DataGridView();
            this.columnA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.columnB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.columnC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.columnD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
            this.SuspendLayout();

            this.dataGrid.AllowUserToAddRows = false;
            this.dataGrid.AllowUserToDeleteRows = false;
            this.dataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.columnA,
            this.columnB,
            this.columnC,
            this.columnD});
            this.dataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGrid.Location = new System.Drawing.Point(0, 0);
            this.dataGrid.Name = "dataGridView1";
            this.dataGrid.Size = new System.Drawing.Size(689, 493);
            this.dataGrid.TabIndex = 0;
            this.dataGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.CellContentClick);

            this.columnA.HeaderText = "A";
            this.columnA.Name = "ColumnA";

            this.columnB.HeaderText = "B";
            this.columnB.Name = "ColumnB";

            this.columnC.HeaderText = "C";
            this.columnC.Name = "ColumnC";

            this.columnD.HeaderText = "D";
            this.columnD.Name = "ColumnD";

            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(689, 493);
            this.Controls.Add(this.dataGrid);
            this.Name = "Form1";
            this.Text = "Hongqi Guo 11552159";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
            this.ResumeLayout(false);

        }
        #endregion
    }
}