﻿// <copyright file="cell.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace CptS321
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// Spreadsheet Engine function.
    /// </summary>
    public abstract class Cell : INotifyPropertyChanged
    {
        /// <summary>
        /// The text of a cell.
        /// </summary>
        protected string myText = string.Empty;

        /// <summary>
        /// The Cell Data value.
        /// </summary>
        protected string myValue = string.Empty;

        /// <summary>
        /// Row index of a cell.
        /// </summary>
        private readonly int rowIndex;

        /// <summary>
        /// Column index of a cell.
        /// </summary>
        private readonly int columnIndex;

        /// <summary>
        /// cell data name.
        /// </summary>
        private readonly string myName;

        /// <summary>
        /// Initializes a new instance of the <see cref="Cell"/> class.
        /// </summary>
        /// <param name="rowIndex">Get row index to my row. </param>
        /// <param name="columnIndex">Get column index to my column.</param>
        public Cell(int rowIndex, int columnIndex)
        {
            this.rowIndex = rowIndex;
            this.columnIndex = columnIndex;
            this.myName += Convert.ToChar('A' + columnIndex);
            this.myName += (rowIndex + 1).ToString();
        }

        /// <summary>
        /// Events for property changed.
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged = (sender, e) => { };

        /// <summary>
        /// Gets the row value then return to row index.
        /// </summary>
        public int RowIndex
        {
            get { return this.rowIndex; }
        }

        /// <summary>
        /// Gets the column value then return to column index.
        /// </summary>
        public int ColumnIndex
        {
            get { return this.columnIndex; }
        }

        /// <summary>
        /// Gets the name then return to name index.
        /// </summary>
        public string Name
        {
            get { return this.myName; }
        }

        /// <summary>
        ///  Gets value, then just return it.
        /// </summary>
        public string Value
        {
            get { return this.myValue; }
        }

        /// <summary>
        /// Gets or sets the text, if value is not text,property change the value.
        /// </summary>
        public string Text
        {
            get
            {
                return this.myText;
            }

            set
            {
                if (this.myText == value)
                {
                    return;
                }

                this.myText = value;
                this.PropertyChanged(this, new PropertyChangedEventArgs("Text"));
            }
        }
    }
}
