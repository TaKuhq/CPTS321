﻿// <copyright file="Form1.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace HW11_Threading_WinForm
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using System.Windows.Forms;

    /// <summary>
    /// Class declarations.
    /// </summary>
    public partial class Form1 : Form
    {
        /// <summary>
        /// globe variable.
        /// </summary>
        private string myUrl;

        /// <summary>
        /// globe variable.
        /// </summary>
        private string myResult;

        /// <summary>
        /// define single thread list.
        /// </summary>
        private List<List<int>> singleThreadlist = new List<List<int>>();

        /// <summary>
        /// define Multiline thread list.
        /// </summary>
        private List<List<int>> mutilThreadlist = new List<List<int>>();

        /// <summary>
        /// Initializes a new instance of the <see cref="Form1"/> class.
        /// </summary>
        public Form1()
        {
            this.InitializeComponent();
            this.myURLbox.Text = "http://www.wsu.edu";
        }

        /// <summary>
        /// get a delegate.
        /// </summary>
        /// <param name="o">object o.</param>
        public delegate void DoDelegate(object o);

        /// <summary>
        /// Click the download button.
        /// </summary>
        /// <param name="sender">The parameter is not used. </param>
        /// <param name="e">The parameter is not used. </param>
        private void Download_btn_Click(object sender, EventArgs e)
        {
            this.myDownloadbox.Clear();
            this.myDownloadbox.Text = "[NOTICE] IF THE WEB STRING IS TOOOOO LONG, SETTING THE TEXT WILL CAUSE LAGGING.\r\n\r\n";
            this.myUrl = this.myURLbox.Text;

            this.IsEnabled_download(false);

            Thread download = new Thread(this.WebDownload);
            download.Start();
        }

        /// <summary>
        /// do the downloading thread.
        /// </summary>
        private void WebDownload()
        {
            if (this.myUrl.Length <= 7)
            {
                this.myResult = "Please enter http:// at the front.";
            }
            else if (this.myUrl.Substring(0, 7) == "http://")
            {
                using (var webClient = new System.Net.WebClient())
                {
                    try
                    {
                        this.myResult = webClient.DownloadString(this.myUrl);
                    }
                    catch
                    {
                        this.myResult = "The website is not responding, plz re-enter url.";
                    }
                }
            }
            else
            {
                this.myResult = "Please enter a valid URL - enter http:// at the front.";
            }

            this.DownloadOutput(this.myResult);
            this.IsEnabled_download(true);
        }

        /// <summary>
        /// set the display depend the downloading finish or not.
        /// </summary>
        /// <param name="myBool">define a boolean value.</param>
        private void IsEnabled_download(bool myBool)
        {
            if (this.myBtnDownload.InvokeRequired || this.myURLbox.InvokeRequired || this.myDownloadbox.InvokeRequired)
            {
                this.myBtnDownload.Invoke(new MethodInvoker(() => this.IsEnabled_download(myBool)));
                this.myURLbox.Invoke(new MethodInvoker(() => this.IsEnabled_download(myBool)));
                this.myDownloadbox.Invoke(new MethodInvoker(() => this.IsEnabled_download(myBool)));
            }
            else
            {
                this.myBtnDownload.Enabled = myBool;
                this.myURLbox.Enabled = myBool;
                this.myDownloadbox.Enabled = myBool;
            }
        }

        /// <summary>
        /// The data from the call.
        /// </summary>
        /// <param name="myValue">data call.</param>
        private void DownloadOutput(object myValue)
        {
            if (this.InvokeRequired)
            {
                DoDelegate method = new DoDelegate(this.DownloadOutput);
                this.Invoke(method, myValue);
                return;
            }

            string text = (string)myValue;
            this.myDownloadbox.Text += text + "\r\n";
        }

        /// <summary>
        /// click the sort button.
        /// </summary>
        /// <param name="sender">The parameter is not used. </param>
        /// <param name="e">The parameter is not used. </param>
        private void Sorting_btn_Click(object sender, EventArgs e)
        {
            this.mySortingBox.Clear();
            this.IsEnabledsort(false);
            this.singleThreadlist = new List<List<int>>();
            this.mutilThreadlist = new List<List<int>>();

            Thread sort = new Thread(this.SortingList);
            sort.Start();
        }

        /// <summary>
        /// do the sorting thread.
        /// </summary>
        /// <param name="myValue">The parameter is not used.</param>
        private void SortingList(object myValue)
        {
            DoDelegate sort = new DoDelegate(this.SortingOutput);

            Random randnum = new Random();

            for (int x = 0; x < 8; x++)
            {
                List<int> sublist = new List<int>();
                List<int> sublist2 = new List<int>();
                for (int y = 0; y < 1000000; y++)
                {
                    sublist.Add(randnum.Next(0, 1000000));
                    sublist2.Add(randnum.Next(0, 1000000));
                }

                this.singleThreadlist.Add(sublist);
                this.mutilThreadlist.Add(sublist2);
            }

            DateTime start = DateTime.Now;

            foreach (var sub in this.singleThreadlist)
            {
                sub.Sort();
            }

            DateTime end = DateTime.Now;

            string singleThread = "Single-threaded time: " + (int)this.TimeDiff(start, end) + " ms";
            sort.Invoke(singleThread);

            Thread multisorting = new Thread(this.MultiSort);
            multisorting.Start();
        }

        /// <summary>
        /// Multiline sort thread.
        /// </summary>
        private void MultiSort()
        {
            DoDelegate multisorting = new DoDelegate(this.SortingOutput);
            List<Thread> list_threads = new List<Thread>();

            DateTime start = DateTime.Now;

            for (int i = 0; i < 8; i++)
            {
                Thread t = new Thread(new ParameterizedThreadStart(this.MySort));
                list_threads.Add(t);
                t.Start(i);
            }

            DateTime end = DateTime.Now;

            foreach (Thread t in list_threads)
            {
                t.Join();
            }

            int count = 0;
            foreach (var sub in this.mutilThreadlist)
            {
                count++;
                for (int i = 0; i < sub.Count - 1; i++)
                {
                    if (sub[i] > sub[i + 1])
                    {
                        multisorting.Invoke("list " + count);
                        multisorting.Invoke("not sorted " + sub[i] + " -> " + sub[i + 1]);
                    }
                }
            }

            string myMultiThread = "Multi-threaded time: " + (int)this.TimeDiff(start, end) + " ms";
            multisorting.Invoke(myMultiThread);
            this.IsEnabledsort(true);
        }

        /// <summary>
        /// sort one list per thread.
        /// </summary>
        /// <param name="myValue">get the value.</param>
        private void MySort(object myValue)
        {
            this.mutilThreadlist[(int)myValue].Sort();
        }

        /// <summary>
        /// cal the diff time.
        /// </summary>
        /// <param name="d1">data time t1.</param>
        /// <param name="d2">data time t2.</param>
        /// <returns>double value.</returns>
        private double TimeDiff(DateTime d1, DateTime d2)
        {
            TimeSpan ts1 = new TimeSpan(d1.Ticks);
            TimeSpan ts2 = new TimeSpan(d2.Ticks);
            TimeSpan ts = ts1.Subtract(ts2).Duration();
            double timeDiff = ts.TotalMilliseconds;
            return timeDiff;
        }

        /// <summary>
        /// invoke sorting output.
        /// </summary>
        /// <param name="myValue">The parameter is not used.</param>
        private void SortingOutput(object myValue)
        {
            if (this.InvokeRequired)
            {
                DoDelegate method = new DoDelegate(this.SortingOutput);

                this.Invoke(method, myValue);

                return;
            }

            string text = myValue.ToString();
            this.mySortingBox.Text += text + "\r\n";
        }

        /// <summary>
        /// form load function.
        /// </summary>
        /// <param name="sender">The parameter is not used. </param>
        /// <param name="e">The parameter is not used. </param>
        private void Form1_Load(object sender, EventArgs e)
        {
        }

        /// <summary>
        /// set the display depend the sorting finish or not.
        /// </summary>
        /// <param name="myBool">define a boolean value.</param>
        private void IsEnabledsort(bool myBool)
        {
            if (this.mySortingBtn.InvokeRequired || this.mySortingBox.InvokeRequired)
            {
                this.mySortingBtn.Invoke(new MethodInvoker(() => this.IsEnabledsort(myBool)));
                this.mySortingBox.Invoke(new MethodInvoker(() => this.IsEnabledsort(myBool)));
            }
            else
            {
                this.mySortingBtn.Enabled = myBool;
                this.mySortingBox.Enabled = myBool;
            }
        }
    }
}