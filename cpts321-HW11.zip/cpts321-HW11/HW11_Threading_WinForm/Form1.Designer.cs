﻿// <copyright file="Form1.Designer.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace HW11_Threading_WinForm
{
    /// <summary>
    /// Form1 Designer function.
    /// </summary>
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// define the sorting button.
        /// </summary>
        private System.Windows.Forms.Button mySortingBtn;

        /// <summary>
        /// define the sorting box.
        /// </summary>
        private System.Windows.Forms.TextBox mySortingBox;

        /// <summary>
        /// define the URL box.
        /// </summary>
        private System.Windows.Forms.TextBox myURLbox;

        /// <summary>
        /// define label.
        /// </summary>
        private System.Windows.Forms.Label label1;

        /// <summary>
        /// define button download.
        /// </summary>
        private System.Windows.Forms.Button myBtnDownload;

        /// <summary>
        /// define download box.
        /// </summary>
        private System.Windows.Forms.TextBox myDownloadbox;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mySortingBtn = new System.Windows.Forms.Button();
            this.mySortingBox = new System.Windows.Forms.TextBox();
            this.myURLbox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.myBtnDownload = new System.Windows.Forms.Button();
            this.myDownloadbox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // sorting_btn
            // 
            this.mySortingBtn.Location = new System.Drawing.Point(13, 12);
            this.mySortingBtn.Name = "sorting_btn";
            this.mySortingBtn.Size = new System.Drawing.Size(409, 21);
            this.mySortingBtn.TabIndex = 0;
            this.mySortingBtn.Text = "Go (sorting)";
            this.mySortingBtn.UseVisualStyleBackColor = true;
            this.mySortingBtn.Click += new System.EventHandler(this.Sorting_btn_Click);
            // 
            // sorting_textbox
            // 
            this.mySortingBox.Location = new System.Drawing.Point(13, 40);
            this.mySortingBox.Multiline = true;
            this.mySortingBox.Name = "sorting_textbox";
            this.mySortingBox.Size = new System.Drawing.Size(412, 530);
            this.mySortingBox.TabIndex = 1;
            // 
            // URL_textBox
            // 
            this.myURLbox.Location = new System.Drawing.Point(431, 23);
            this.myURLbox.Name = "URL_textBox";
            this.myURLbox.Size = new System.Drawing.Size(558, 21);
            this.myURLbox.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(428, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "URL";
            // 
            // download_btn
            // 
            this.myBtnDownload.Location = new System.Drawing.Point(431, 47);
            this.myBtnDownload.Name = "download_btn";
            this.myBtnDownload.Size = new System.Drawing.Size(558, 21);
            this.myBtnDownload.TabIndex = 4;
            this.myBtnDownload.Text = "Go (download string from URL)";
            this.myBtnDownload.UseVisualStyleBackColor = true;
            this.myBtnDownload.Click += new System.EventHandler(this.Download_btn_Click);
            // 
            // download_textBox
            // 
            this.myDownloadbox.Location = new System.Drawing.Point(431, 74);
            this.myDownloadbox.Multiline = true;
            this.myDownloadbox.Name = "download_textBox";
            this.myDownloadbox.Size = new System.Drawing.Size(558, 496);
            this.myDownloadbox.TabIndex = 5;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1001, 581);
            this.Controls.Add(this.myDownloadbox);
            this.Controls.Add(this.myBtnDownload);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.myURLbox);
            this.Controls.Add(this.mySortingBox);
            this.Controls.Add(this.mySortingBtn);
            this.Name = "Form1";
            this.Text = "Hongqi Guo 11552159";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();
        }
        #endregion
    }
}
