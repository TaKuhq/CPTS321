﻿//-----------------------------------------------------------------------
// <copyright file="HW1.cs" company="My Company"">
//     Company copyright tag.
// </copyright>
//-----------------------------------------------------------------------
namespace HW1
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// This is HW1 class.
    /// </summary>
    public class HW1
    {
        /// <summary>
        /// get user input.
        /// </summary>
        /// <returns> return inputIntegerList </returns>
        private static int[] GetGetinput()
        {
            string input = Console.ReadLine();
            string[] list = input.Split();
            int[] inputIntegerList = Array.ConvertAll(list, int.Parse);

            ////retrun input,then will be used by m1.
            return inputIntegerList;
        }
        
        /// <summary>
        /// This is the body of the BST Tree.
        /// </summary>
        /// <param name="args"> The args is string.</param>
        static void Main(string[] args)
        {
            ////Numerical initialization
            IntNode root = null;
            BST tree = new BST();
            double min = 0;

            //// m1. get user input
            Console.WriteLine("Enter a collection of numbers in the range [0, 100], seperated by spaces: ");
            int[] userInput = GetGetinput();
            ////Check for duplicate fields
            List<int> value = new List<int>();

            ////Iterate through the groups.
            for (int i = 0; i < userInput.Length; i++)
            {
                ////If the value does not repeat, insert and output.
                if (value.Contains(userInput[i]) == false)
                {
                    root = tree.Insertdata(root, userInput[i]);
                    value.Add(userInput[i]);
                }
            }
            ////print tree contents
            Console.WriteLine("Tree contents: ");
            tree.Display(root);
            Console.WriteLine("Tree statistics:");

            ////print number of nodes
            int track = tree.CountNode(root);
            Console.WriteLine("Number of nodes: " + track);

            ////print number of levels
            int depth = tree.Height(root);
            Console.WriteLine("Number of levels: " + depth);

            //// min level is n=log(base 2)x +1
            ////print minimum number:
           min = Math.Floor(Math.Log(track + 1, 2));
            Console.WriteLine("Minimum number of levels that a tree with " + track + " nodes could have = " + min);
        }
    }

    /// <summary>
    /// class integer node is an object used as a binary tree node.
    /// </summary>
    class IntNode
    {
        /// <summary>
        /// a number as data.
        /// </summary>
        public int NUMBER;

        /// <summary>
        /// Two contain number nodes.
        /// </summary>
        public IntNode LEFTLEAF;

        /// <summary>
        /// RIGHTLEAF number node
        /// </summary>
        public IntNode RIGHTLEAF;
    }

    /// <summary>
    /// BST tree body function.
    /// </summary>
    class BST
    {
        /// <summary>
        /// takes in a node and data to be inserted and then inserts the node into the proper location based off the data.
        /// </summary>
        /// <param name="node"> Get the value of node.</param>
        /// <param name="newData">Save the data in new data.</param>
        /// <returns> return node </returns>
        public IntNode Insertdata(IntNode node, int newData)
        {
            if (node == null)
            {
                node = new IntNode();
                node.NUMBER = newData;
            }
            else if (node.NUMBER < newData)
            {
                node.RIGHTLEAF = this.Insertdata(node.RIGHTLEAF, newData);
            }
            else
            {
                node.LEFTLEAF = this.Insertdata(node.LEFTLEAF, newData);
            }

            return node;
        }

        /// <summary>
        /// counts the height of the tree recursive.
        /// </summary>
        /// <param name="root">get the tree height</param>
        /// <returns>return height </returns>
        public int Height(IntNode root)
        {
            int leftLeaf = 0;
            int rightLeaf = 0;

            if (root == null)
            {
                return 0;
            }
            else
            {
                leftLeaf = 1 + this.Height(root.LEFTLEAF);
            }

            if (root == null)
            {
                return 0;
            }
            else
            {
                rightLeaf = 1 + this.Height(root.RIGHTLEAF);
            }

            if (rightLeaf > leftLeaf)
            {
                return rightLeaf;
            }
            else
            {
                return leftLeaf;
            }
        }

        /// <summary>
        /// Prints the data of the node.
        /// </summary>
        /// <param name="x"> x is the tree node.</param>
        public void Display(IntNode x)
        {
            if (x == null)
            {
                return;
            }

            this.Display(x.LEFTLEAF);
            Console.Write(" " + x.NUMBER);
            this.Display(x.RIGHTLEAF);
        }

        /// <summary>
        /// Get the number of nodes.
        /// </summary>
        /// <param name="d"> d is the tree node</param>
        /// <returns> return count </returns>
        public int CountNode(IntNode d)
        {
            ////Initialize count to 1.
            int count = 1;
            if (d == null)
            {
                return 0;
            }

            ////There are two cases, left node and right node.
            if (d.LEFTLEAF != null)
            {
                count += this.CountNode(d.LEFTLEAF);
            }

            if (d.RIGHTLEAF != null)
            {
                count += this.CountNode(d.RIGHTLEAF);
            }

            return count;
        }
    }
}
