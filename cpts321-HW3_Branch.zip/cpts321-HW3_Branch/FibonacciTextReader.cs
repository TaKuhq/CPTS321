﻿//-----------------------------------------------------------------------
// <copyright file="FibonacciTextReader.cs" company="My company">
// Class: CPTS321
// HW3: WinForms “Notepad” Application / Fibonacci BigInt Text Reader
// Name:Hongqi Guo
// ID: 011552159
// </copyright>
//-----------------------------------------------------------------------

namespace HW3
{
    using System;

    /// <summary>
    /// These integers record the number of rows and the current leading position of the reader.
    /// </summary>
    public class FibonacciTextReader : System.IO.TextReader
    {
        /// <summary>
        /// This is the initialization data.
        /// </summary>
        private int lines;

        /// <summary>
        /// This is the initialization data.
        /// </summary>
        private int currentLine = 1;

        /// <summary>
        /// Initializes a new instance of the <see cref="FibonacciTextReader"/> class.
        /// </summary>
        /// <param name="line">An integer value.</param>
        public FibonacciTextReader(int line)
        {
            this.lines = line;
        }

        /// <summary>
        /// Store the data in the Read Line.
        /// </summary>
        /// <returns>Fibonacci Number string.</returns>
        public override string ReadLine()
        {
            return Fibonacci.FibonacciNumber(this.currentLine).ToString();
        }

        /// <summary>
        /// Read the numbers and loop.
        /// </summary>
        /// <returns> return the string.</returns>
        public override string ReadToEnd()
        {
            string numbers = string.Empty;
            while (this.currentLine <= this.lines)
            {
                numbers += $"{this.currentLine}: " + this.ReadLine();
                if (this.currentLine != this.lines)
                {
                    numbers += Environment.NewLine;
                }

                this.currentLine++;
            }

            return numbers;
        }
    }
}
