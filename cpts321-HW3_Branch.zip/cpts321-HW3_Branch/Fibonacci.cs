﻿//-----------------------------------------------------------------------
// <copyright file="Fibonacci.cs" company="My company">
// Class: CPTS321
// HW3: WinForms “Notepad” Application / Fibonacci BigInt Text Reader
// Name:Hongqi Guo
// ID: 011552159
// </copyright>
//-----------------------------------------------------------------------

namespace HW3
{
    using System.Numerics;

    /// <summary>
    /// This is the basic function of the Fibonacci sequence.
    /// </summary>
    public class Fibonacci
    {
        /// <summary>
        /// Calculate the output number by Fibonacci sequence.
        /// </summary>
        /// <param name="number">An integer value. </param>
        /// <returns>If the number is one, output one.If the number is greater than one, the calculation outputs the final value.</returns>
        public static BigInteger FibonacciNumber(int number)
        {
            BigInteger a = 0, b = 1, c;
            if (number == 1)
            {
                return a;
            }
            else
            {
                for (int i = 3; i <= number; i++)
                {
                    c = a + b;
                    a = b;
                    b = c;
                }

                return b;
            }
        }
    }
}
