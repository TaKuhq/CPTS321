﻿//-----------------------------------------------------------------------
// <copyright file="Form1.Designer.cs" company="My company">
// Class: CPTS321
// HW3: WinForms “Notepad” Application / Fibonacci BigInt Text Reader
// Name:Hongqi Guo
// ID: 011552159
// </copyright>
//-----------------------------------------------------------------------

namespace HW3
{
    using System.Windows.Forms;

    /// <summary>
    /// Form1 Designer function.
    /// </summary>
    public partial class Form1
    {
        /// <summary>
        /// Define the MenuStrip system.
        /// </summary>
        private System.Windows.Forms.MenuStrip menuStrip1;

        /// <summary>
        /// Define the TextBox system.
        /// </summary>
        private System.Windows.Forms.TextBox textBox1;

        /// <summary>
        /// Define the ToolStripMenuItem system.
        /// </summary>
        private System.Windows.Forms.ToolStripMenuItem textToolStripMenuItem;

        /// <summary>
        /// Required designer variables.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up all resources that are in use.
        /// </summary>
        /// <param name="disposing">True if the managed resource should be released;Otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// The designer supports the required methods - do not modify
        /// Modify the contents of this method using the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.textToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.textToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.MenuStrip1_ItemClicked);
            // 
            // textToolStripMenuItem
            // 
            this.textToolStripMenuItem.Name = "textToolStripMenuItem";
            this.textToolStripMenuItem.Size = new System.Drawing.Size(39, 21);
            this.textToolStripMenuItem.Text = "File";
            this.textToolStripMenuItem.DropDownItems.Add("Load File").Click += new System.EventHandler(LoadFile);
            this.textToolStripMenuItem.DropDownItems.Add("Load Fibonacci numbers (first 50)").Click += new System.EventHandler(FibonacciNumbers_50);
            this.textToolStripMenuItem.DropDownItems.Add("Load Fibonacci numbers (first 100)").Click += new System.EventHandler(FibonacciNumbers_100);
            this.textToolStripMenuItem.DropDownItems.Add(new ToolStripSeparator());
            this.textToolStripMenuItem.DropDownItems.Add("Save File").Click += new System.EventHandler(SaveFile);
            // 
            // textBox1
            // 
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox1.Location = new System.Drawing.Point(0, 25);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox1.Size = new System.Drawing.Size(800, 425);
            this.textBox1.TabIndex = 2;

            this.textBox1.TextChanged += new System.EventHandler(this.TextBox1_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Hongqi";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
    }
}
