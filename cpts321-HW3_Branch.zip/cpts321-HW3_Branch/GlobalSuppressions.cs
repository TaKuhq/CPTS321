﻿//-----------------------------------------------------------------------
// File header copyright text should match
// <copyright file="GlobalSuppressions.cs" company="My company">
// Class: CPTS321
// HW3: WinForms “Notepad” Application / Fibonacci BigInt Text Reader
// Name:Hongqi Guo
// ID: 011552159
// </copyright>
//-----------------------------------------------------------------------
using System.Diagnostics.CodeAnalysis;
#pragma warning restore SA1636 // File header copyright text should match

[assembly: SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1636:File header copyright text should match", Justification = "<挂起>", Scope = "namespace", Target = "~N:HW3")]
[assembly: SuppressMessage("StyleCop.CSharp.ReadabilityRules", "SA1122:Use string.Empty for empty strings", Justification = "<挂起>", Scope = "member", Target = "~M:HW3.FibonacciTextReader.ReadToEnd~System.String")]
[assembly: SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1636:File header copyright text should match", Justification = "<挂起>")]
