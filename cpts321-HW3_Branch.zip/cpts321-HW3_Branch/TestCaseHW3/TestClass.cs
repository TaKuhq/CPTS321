﻿//-----------------------------------------------------------------------
// <copyright file="TestClass.cs" company="My company">
// Class: CPTS321
// HW3: WinForms “Notepad” Application / Fibonacci BigInt Text Reader
// Name:Hongqi Guo
// ID: 011552159
// NUnit 3 tests
// See documentation : https://github.com/nunit/docs/wiki/NUnit-Documentation
// </copyright>
//-----------------------------------------------------------------------

namespace HW3
{
    using System.Numerics;
    using NUnit.Framework;

    /// <summary>
    /// Test cases, five in all
    /// </summary>
    [TestFixture]
    public class TestClass
    {
        /// <summary>
        /// This is the first test that checks to see if the fifty digits of the Fibonacci function are the same.
        /// </summary>
        [Test]
        public void TestCase1()
        {
            Assert.AreEqual(BigInteger.Parse("7778742049"), HW3.Fibonacci.FibonacciNumber(50));
        }

        /// <summary>
        /// This is the second test case. The test project is to check whether the 100 Fibonacci value is correct.
        /// </summary>
        [Test]
        public void TestCase2()
        {
            Assert.AreEqual(BigInteger.Parse("218922995834555169026"), HW3.Fibonacci.FibonacciNumber(100));
        }

        /// <summary>
        /// This is the third test case, and the test project is to check if the first Fibonacci value was correct.
        /// </summary>
        [Test]
        public void TestCase3()
        {
            Assert.AreEqual(BigInteger.Parse("1"), HW3.Fibonacci.FibonacciNumber(0));
        }

        /// <summary>
        /// This is the fourth test case. The test project is to check whether the value of the thousandth Fibonacci is correct.
        /// </summary>
        [Test]
        public void TestCase4()
        {
            Assert.AreEqual(BigInteger.Parse("26863810024485359386146727202142923967616609318986952340123175997617981700247881689338369654483356564191827856161443356312976673642210350324634850410377680367334151172899169723197082763985615764450078474174626"), HW3.Fibonacci.FibonacciNumber(1000));
        }

        ////Because Fibonacci Numbers are in a linear recursion sequence, there is no overflow.
    }
}
