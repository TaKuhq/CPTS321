﻿//-----------------------------------------------------------------------
// <copyright file="Form1.cs" company="My company">
// Class: CPTS321
// HW3: WinForms “Notepad” Application / Fibonacci BigInt Text Reader
// Name:Hongqi Guo
// ID: 011552159
// </copyright>
//-----------------------------------------------------------------------

namespace HW3
{
    using System;
    using System.IO;
    using System.Windows.Forms;

    /// <summary>
    /// That's the beginning of Form1.
    /// </summary>
    public partial class Form1 : Form
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Form1"/> class.
        /// </summary>
        public Form1()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// The system comes with its own function.
        /// </summary>
        /// <param name="sender"> return null.</param> 
        /// <param name="e"> this null.</param>
        private void Form1_Load(object sender, EventArgs e)
        {
        }

        /// <summary>
        /// Load the file,Before loading, clear whatever text is currently in the text box.
        /// </summary>
        /// <param name="sr">Text Reader parameter.</param>
        private void LoadText(TextReader sr)
        {
            this.textBox1.Clear();
            try
            {
                this.textBox1.AppendText(sr.ReadToEnd());
            }
            catch (Exception e)
            {
                MessageBox.Show("Error: couldn't read file from disk. Original Error: " + e.Message);
            }
        }

        /// <summary>
        /// Open the file and load the text into the text box.
        /// </summary>
        /// <param name="sender">Load File parameter.</param>
        /// <param name="e">The parameter is not used. </param>
        private void LoadFile(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog
            {
                Title = "Select a file to be read and displayed in the window.",
                Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*",
                FilterIndex = 2,
            };

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                using (StreamReader sr = new StreamReader(openFileDialog1.FileName))
                {
                    this.LoadText(sr);
                }
            }
        }

        /// <summary>
        /// Fibonacci are numbered at 50.
        /// </summary>
        /// <param name="sender">Load File parameter.</param>
        /// <param name="e">The parameter is not used. </param>
        private void FibonacciNumbers_50(object sender, EventArgs e)
        {
            using (FibonacciTextReader ftr = new FibonacciTextReader(50))
            {
                this.LoadText(ftr);
            }
        }

        /// <summary>
        /// Fibonacci are numbered at 100.
        /// </summary>
        /// <param name="sender">Load File parameter.</param>
        /// <param name="e">The parameter is not used. </param>
        private void FibonacciNumbers_100(object sender, EventArgs e)
        {
            using (FibonacciTextReader ftr = new FibonacciTextReader(100))
            {
                this.LoadText(ftr);
            }
        }

        /// <summary>
        /// The action of saving a file.
        /// </summary>
        /// <param name="sender">Load File parameter.</param>
        /// <param name="e">The parameter is not used. </param>
        private void SaveFile(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog
            {
                Title = "Save the text in the window to a file.",
                Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*",
                FilterIndex = 2,
            };

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                using (StreamWriter sw = new StreamWriter(saveFileDialog1.FileName))
                {
                    try
                    {
                        sw.Write(this.textBox1.Text);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: writing window's text to file failure. Original Error: " + ex.Message);
                    }
                }
            }
        }

        /// <summary>
        /// Nonsense operation.
        /// </summary>
        /// <param name="sender">Load File parameter.</param>
        /// <param name="e">The parameter is not used. </param>
        private void TextBox1_TextChanged(object sender, EventArgs e)
        {
        }

        /// <summary>
        /// Nonsense operation.
        /// </summary>
        /// <param name="sender">Load File parameter.</param>
        /// <param name="e">The parameter is not used. </param>
        private void MenuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
        }
    }
}
