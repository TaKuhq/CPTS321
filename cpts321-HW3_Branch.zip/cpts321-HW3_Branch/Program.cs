﻿//-----------------------------------------------------------------------
// <copyright file="Program.cs" company="My company">
// Class: CPTS321
// HW3: WinForms “Notepad” Application / Fibonacci BigInt Text Reader
// Name:Hongqi Guo
// ID: 011552159
// </copyright>
//-----------------------------------------------------------------------
namespace HW3
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using System.Windows.Forms;
    
    /// <summary>
    /// this is main function.
    /// </summary>
    public static class Program
    {
        /// <summary>
        /// The main entry point to the application.
        /// </summary>
        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
