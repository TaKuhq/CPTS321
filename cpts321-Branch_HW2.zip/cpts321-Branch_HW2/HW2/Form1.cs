﻿//-----------------------------------------------------------------------
// <copyright file="Form1.cs" company="My company">
// Class: CPTS321
// HW2: WinFormsAndDotNet
// Name:Hongqi Guo
// ID: 011552159
// </copyright>
//-----------------------------------------------------------------------

namespace HW2
{
    using System;
    using System.Collections.Generic;
    using System.Windows.Forms;

    /// <summary>
    /// Form1 class.
    /// </summary>
    public partial class Form1 : Form
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Form1"/> class.
        /// </summary>
        public Form1()
        {
            this.InitializeComponent();
        }


        /// <summary>
        /// new class name
        /// </summary>
        /// <param name="sender"> sender name</param>
        /// <param name="e">value e </param>
        private void Form1load(object sender, EventArgs e)
        {
            //// A variable that generates a list of random integer values
            int minRange = 0, maxRange = 20000, maxSize = 10000, value1 = 0, value2 = 0, value3 = 0;

            ////create a list
            List<int> numbers = new List<int>(maxSize);

            ////create object of random class
            Random rand = new Random();

            //// take random number between 0 and 20000 and add numbers to list
            for (int i = 0; i < maxSize; i++)
            {
                numbers.Add(rand.Next(minRange, maxRange));
            }

            //// 1. Use hash set to determine the number of distinct ingtegers in the list.
            HashSet<int> valuelist = new HashSet<int>();

            //// insert the random integers in the hashset
            foreach (int x in numbers)
            {
                if (!valuelist.Contains(x))
                {
                    valuelist.Add(x);
                }
            }



            value1 = valuelist.Count;

            ////2. two loops to compare every value to every value in the same randomInts list, the time complexity worst case is O(n)^2
            int cont = 0;

            for (int y = 0; y < maxSize; y++)
            {
                //// if it's true,
                bool mybool = true;
                ////Prevent the occurrence of the same value
                for (int z = y + 1; z < maxSize && mybool; z++)
                {
                    if (numbers[y] == numbers[z])
                    {
                        mybool = false;
                        cont++;
                    }
                }
            }
            ////he storage complexity at O(1).
            value2 = maxSize - cont;

            ////3.Sort the list using the built-in sort function
            numbers.Sort();

            for (int h = 0; h < maxSize; h++)
            {
                if (h == (maxSize - 1))
                {
                    value3++;
                }
                else if (numbers[h] < numbers[h + 1])
                {
                    value3++;
                }
            }

            this.textBox1.Text = "1. Hashset Method: " + value1.ToString() + " unique numbers" + Environment.NewLine +
                            "The time complexity is O(n), using a forloop to get the list." + Environment.NewLine +
                            "2. O(1) storage method: " + value2.ToString() + " unique numbers" + Environment.NewLine +
                            "3. Sorted method: " + value3.ToString() + " unique numbers" + Environment.NewLine;
        }
    }
}
