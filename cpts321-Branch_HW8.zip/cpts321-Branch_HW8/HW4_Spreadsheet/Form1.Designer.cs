﻿// <copyright file="Form1.Designer.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>
namespace HW7_Spreadsheet
{
    /// <summary>
    /// Form1 Designer function.
    /// </summary>
    public partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Define the DataGridView system.
        /// </summary>
        private System.Windows.Forms.DataGridView dataGrid;

        /// <summary>
        /// Define the columnA.
        /// </summary>
        private System.Windows.Forms.DataGridViewTextBoxColumn columnA;

        /// <summary>
        /// Define the columnB.
        /// </summary>
        private System.Windows.Forms.DataGridViewTextBoxColumn columnB;

        /// <summary>
        /// Define the columnC.
        /// </summary>
        private System.Windows.Forms.DataGridViewTextBoxColumn columnC;

        /// <summary>
        /// Define the columnD.
        /// </summary>
        private System.Windows.Forms.DataGridViewTextBoxColumn columnD;

        /// <summary>
        /// Define the menu strip.
        /// </summary>
        private System.Windows.Forms.MenuStrip menuStrip1;

        /// <summary>
        /// define the edit tool.
        /// </summary>
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;

        /// <summary>
        /// define the redo tool.
        /// </summary>
        private System.Windows.Forms.ToolStripMenuItem redoToolStripMenuItem;

        /// <summary>
        /// define the cell tool.
        /// </summary>
        private System.Windows.Forms.ToolStripMenuItem cellToolStripMenuItem;

        /// <summary>
        /// define the choose background color tool.
        /// </summary>
        private System.Windows.Forms.ToolStripMenuItem chooseBackgroundColorToolStripMenuItem;

        /// <summary>
        /// define the undo tool.
        /// </summary>
        private System.Windows.Forms.ToolStripMenuItem undoToolStripMenuItem;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (this.components != null))
            {
                this.components.Dispose();
            }

            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGrid = new System.Windows.Forms.DataGridView();
            this.columnA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.columnB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.columnC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.columnD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.undoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.redoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cellToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chooseBackgroundColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();

            this.dataGrid.AllowUserToAddRows = false;
            this.dataGrid.AllowUserToDeleteRows = false;
            this.dataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.columnA,
            this.columnB,
            this.columnC,
            this.columnD});
            this.dataGrid.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGrid.Location = new System.Drawing.Point(0, 25);
            this.dataGrid.Name = "dataGridView1";
            this.dataGrid.Size = new System.Drawing.Size(689, 509);
            this.dataGrid.TabIndex = 0;

            this.columnA.HeaderText = "A";
            this.columnA.Name = "ColumnA";

            this.columnB.HeaderText = "B";
            this.columnB.Name = "ColumnB";

            this.columnC.HeaderText = "C";
            this.columnC.Name = "ColumnC";

            this.columnD.HeaderText = "D";
            this.columnD.Name = "ColumnD";

            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.editToolStripMenuItem,
            this.cellToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(689, 25);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";

            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.undoToolStripMenuItem,
            this.redoToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(42, 21);
            this.editToolStripMenuItem.Text = "Edit";
 
            this.undoToolStripMenuItem.Name = "undoToolStripMenuItem";
            this.undoToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.undoToolStripMenuItem.Text = "Undo";
            this.undoToolStripMenuItem.Click += new System.EventHandler(this.UndoToolStripMenuItem_Click);
 
            this.redoToolStripMenuItem.Name = "redoToolStripMenuItem";
            this.redoToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.redoToolStripMenuItem.Text = "Redo";
            this.redoToolStripMenuItem.Click += new System.EventHandler(this.RedoToolStripMenuItem_Click);

            this.cellToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.chooseBackgroundColorToolStripMenuItem});
            this.cellToolStripMenuItem.Name = "cellToolStripMenuItem";
            this.cellToolStripMenuItem.Size = new System.Drawing.Size(41, 21);
            this.cellToolStripMenuItem.Text = "Cell";

            this.chooseBackgroundColorToolStripMenuItem.Name = "chooseBackgroundColorToolStripMenuItem";
            this.chooseBackgroundColorToolStripMenuItem.Size = new System.Drawing.Size(238, 22);
            this.chooseBackgroundColorToolStripMenuItem.Text = "Choose background color...";
            this.chooseBackgroundColorToolStripMenuItem.Click += new System.EventHandler(this.ColorToolStripMenuItem);

            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(689, 534);
            this.Controls.Add(this.dataGrid);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Hongqi Guo 11552159";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion
    }
}
