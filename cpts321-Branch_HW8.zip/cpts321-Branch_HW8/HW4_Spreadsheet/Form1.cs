﻿// <copyright file="Form1.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace HW7_Spreadsheet
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Windows.Forms;
    using CptS321;
    using SpreadsheetEngine;

    /// <summary>
    /// Class declarations.
    /// </summary>
    public partial class Form1 : Form
    {
        /// <summary>
        /// Initialize the data in sheet.
        /// </summary>
        private Spreadsheet mySheet = new Spreadsheet(50, 26);

        /// <summary>
        /// define the redo.
        /// </summary>
        private UndoRedoClass unRedo = new UndoRedoClass();

        /// <summary>
        /// Initializes a new instance of the <see cref="Form1"/> class.
        /// </summary>
        public Form1()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// cell begin edit function..
        /// </summary>
        /// <param name="sender">The parameter is not used. </param>
        /// <param name="e">The parameter is not used. </param>
        public void CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            int row = e.RowIndex, column = e.ColumnIndex;

            Cell spreadsheetCell = this.mySheet.GetCell(row, column);

            this.dataGrid.Rows[row].Cells[column].Value = spreadsheetCell.Text;
        }

        /// <summary>
        /// cell end edit function.
        /// </summary>
        /// <param name="sender">The parameter is not used. </param>
        /// <param name="e">The parameter is not used. </param>
        public void CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            int row = e.RowIndex, column = e.ColumnIndex;
            string myText;

            ICmdSystem[] undos = new ICmdSystem[1];

            Cell spreadsheetCell = this.mySheet.GetCell(row, column);

            undos[0] = new RestoreText(spreadsheetCell.Text, spreadsheetCell.Name);

            try
            {
                myText = this.dataGrid.Rows[row].Cells[column].Value.ToString();
            }
            catch (NullReferenceException)
            {
                myText = string.Empty;
            }

            spreadsheetCell.Text = myText;
            MultiCmds tmpcmd = new MultiCmds(undos, "cell text change");
            this.unRedo.AddUndos(tmpcmd);
            this.dataGrid.Rows[row].Cells[column].Value = spreadsheetCell.Value;
            this.RefreshUndoRedoButtons();
        }

        /// <summary>
        /// setup the columns,rows and resize the row headers.
        /// </summary>
        /// <param name="sender">The parameter is not used. </param>
        /// <param name="e">The parameter is not used. </param>
        private void Form1_Load(object sender, EventArgs e)
        {
            this.mySheet.CellPropertyChanged += this.OnCellPropertyChanged;
            this.dataGrid.CellBeginEdit += this.CellBeginEdit;
            this.dataGrid.CellEndEdit += this.CellEndEdit;

            this.dataGrid.Columns.Clear();
            string letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            for (int i = 0; i <= 25; i++)
            {
                this.dataGrid.Columns.Add(letters[i].ToString(), letters[i].ToString());
            }

            this.dataGrid.Rows.Add(50);
            for (int i = 0; i < 50; i++)
            {
                var row = this.dataGrid.Rows[i];
                row.HeaderCell.Value = (i + 1).ToString();
            }

            this.RefreshUndoRedoButtons();
        }

        /// <summary>
        /// on cell property change.
        /// </summary>
        /// <param name="sender">The parameter is not used. </param>
        /// <param name="e">The parameter is not used. </param>
        private void OnCellPropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            Cell selectedCell = sender as Cell;

            if (e.PropertyName == "Value" && selectedCell != null)
            {
                this.dataGrid.Rows[selectedCell.RowIndex].Cells[selectedCell.ColumnIndex].Value = selectedCell.Value;
            }

            if (e.PropertyName == "BGColor" && selectedCell != null)
            {
                this.dataGrid.Rows[selectedCell.RowIndex].Cells[selectedCell.ColumnIndex].Style.BackColor = Color.FromArgb((int)selectedCell.BGColor);
            }
        }

        /// <summary>
        /// button for change color.
        /// </summary>
        /// <param name="sender">The parameter is not used. </param>
        /// <param name="e">The parameter is not used. </param>
        private void ColorToolStripMenuItem(object sender, EventArgs e)
        {
            int selectedColor = 0;

            List<ICmdSystem> undos = new List<ICmdSystem>();

            ColorDialog colorDialog = new ColorDialog();

            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                selectedColor = colorDialog.Color.ToArgb();

                foreach (DataGridViewCell cell in this.dataGrid.SelectedCells)
                {
                    Cell spreadsheetCell = this.mySheet.GetCell(cell.RowIndex, cell.ColumnIndex);

                    RestoreBGColor tempBGClass = new RestoreBGColor((int)spreadsheetCell.BGColor, spreadsheetCell.Name);

                    undos.Add(tempBGClass);

                    spreadsheetCell.BGColor = (uint)selectedColor;
                }

                MultiCmds tempCmd = new MultiCmds(undos, "changing cell background color");

                this.unRedo.AddUndos(tempCmd);

                this.RefreshUndoRedoButtons();
            }
        }

        /// <summary>
        /// undo button.
        /// </summary>
        /// <param name="sender">The parameter is not used. </param>
        /// <param name="e">The parameter is not used. </param>
        private void UndoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.unRedo.Undo(this.mySheet);
            this.RefreshUndoRedoButtons();
        }

        /// <summary>
        /// redo button.
        /// </summary>
        /// <param name="sender">The parameter is not used. </param>
        /// <param name="e">The parameter is not used. </param>
        private void RedoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.unRedo.Redo(this.mySheet);
            this.RefreshUndoRedoButtons();
        }

        /// <summary>
        /// update the menu content.
        /// </summary>
        private void RefreshUndoRedoButtons()
        {
            ToolStripItemCollection tempColl = this.menuStrip1.Items;
            ToolStripMenuItem tempMenus = tempColl[0] as ToolStripMenuItem;
            for (int i = 0; i < tempMenus.DropDownItems.Count; i++)
            {
                if (tempMenus.DropDownItems[i].Text[0] == 'U')
                {
                    bool undo = this.unRedo.CanUndo;
                    tempMenus.DropDownItems[i].Enabled = undo;
                    tempMenus.DropDownItems[i].Text = "Undo " + this.unRedo.UndoNext;
                }
                else if (tempMenus.DropDownItems[i].Text[0] == 'R')
                {
                    bool redo = this.unRedo.CanRedo;
                    tempMenus.DropDownItems[i].Enabled = redo;
                    tempMenus.DropDownItems[i].Text = "Redo " + this.unRedo.RedoNext;
                }
            }
        }
    }
}