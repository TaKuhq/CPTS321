﻿// <copyright file="RestoreBGColor.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace SpreadsheetEngine
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using CptS321;

    /// <summary>
    /// define the restore color class.
    /// </summary>
    public class RestoreBGColor : ICmdSystem
    {
        /// <summary>
        /// define the color.
        /// </summary>
        private int myColor;

        /// <summary>
        /// define the name.
        /// </summary>
        private string myName;

        /// <summary>
        /// Initializes a new instance of the <see cref="RestoreBGColor"/> class.
        /// </summary>
        /// <param name="cellColor">call the color.</param>
        /// <param name="cellName">call the name.</param>
        public RestoreBGColor(int cellColor, string cellName)
        {
            this.myColor = cellColor;
            this.myName = cellName;
        }

        /// <summary>
        /// Restores old color for a cell.
        /// </summary>
        /// <param name="mySheet">event sheet.</param>
        /// <returns>old color class.</returns>
        public ICmdSystem Exec(Spreadsheet mySheet)
        {
            Cell cell = mySheet.GetCell(this.myName);

            int old = (int)cell.BGColor;

            cell.BGColor = (uint)this.myColor;

            RestoreBGColor oldBGClass = new RestoreBGColor(old, this.myName);

            return oldBGClass;
        }
    }
}
