﻿// <copyright file="ExpressionTree.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace CptS321
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// This is the definition of ExpressionTree class.
    /// </summary>
    public class ExpressionTree
    {
        /// <summary>
        /// a member dictionary.
        /// </summary>
        private static readonly Dictionary<string, double> MyVars = new Dictionary<string, double>();

        /// <summary>
        /// define a node, my root.
        /// </summary>
        private readonly Node myRoot;

        /// <summary>
        /// Initializes a new instance of the <see cref="ExpressionTree"/> class.
        /// </summary>
        public ExpressionTree()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ExpressionTree"/> class.
        /// </summary>
        /// <param name="expression">String name.</param>
        public ExpressionTree(string expression)
        {
            this.myRoot = Compile(expression);
        }

        /// <summary>
        /// Test helper function, get dictionary value.
        /// </summary>
        /// <param name="a">A string value.</param>
        /// <returns>A double number.</returns>
        public double Lookup(string a)
        {
            return MyVars[a];
        }

        /// <summary>
        /// Sets the specified variable within the ExpressionTree variables dictionary.
        /// </summary>
        /// <param name="variableName">A string name.</param>
        /// <param name="variableValue">A double value.</param>
        public void SetVariable(string variableName, double variableValue)
        {
            MyVars[variableName] = variableValue;
        }

        /// <summary>
        /// Implement this method with no parameters that evaluates the expression to a double value.
        /// </summary>
        /// <returns>A double value.</returns>
        public double Evaluate()
        {
            if (this.myRoot != null)
            {
                return this.myRoot.Eval();
            }
            else
            {
                return double.NaN;
            }
        }

        /// <summary>
        /// get the all variables.
        /// </summary>
        /// <returns>a string.</returns>
        public string[] GetAllVariables()
        {
            return MyVars.Keys.ToArray();
        }

        /// <summary>
        /// string to integer.
        /// </summary>
        /// <param name="value">A string.</param>
        /// <returns>A integer.</returns>
        private static Node Getint(string value)
        {
            if (double.TryParse(value, out double myNum))
            {
                return new ValueNode(myNum);
            }

            return new VarNode(value);
        }

        /// <summary>
        /// Get Low Op Index.
        /// </summary>
        /// <param name="expression">get string.</param>
        /// <returns>return integer.</returns>
        private static int GetLowOpIndex(string expression)
        {
            int parenCounter = 0;
            int index = -1;
            for (int i = expression.Length - 1; i >= 0; i--)
            {
                switch (expression[i])
                {
                    case ')':
                        parenCounter--;
                        break;
                    case '(':
                        parenCounter++;
                        break;
                    case '+':
                    case '-':
                        if (parenCounter == 0)
                        {
                            return i;
                        }

                        break;
                    case '*':
                    case '/':
                        if (parenCounter == 0 && index == -1)
                        {
                            index = i;
                        }

                        break;
                }
            }

            return index;
        }

        /// <summary>
        /// This function does is it makes a tree.
        /// </summary>
        /// <param name="expression">A string name.</param>
        /// <returns>cant return a public type.</returns>
        private static Node Compile(string expression)
        {
            expression = expression.Replace(" ", string.Empty);
            if (expression == string.Empty)
            {
                return null;
            }

            if (expression[0] == '(')
            {
                int counter = 1;
                for (int i = 1; i < expression.Length; i++)
                {
                    if (expression[i] == ')')
                    {
                        counter--;
                        if (counter == 0)
                        {
                            if (i == expression.Length - 1)
                            {
                                return Compile(expression.Substring(1, expression.Length - 2));
                            }
                            else
                            {
                                break;
                            }
                        }
                    }

                    if (expression[i] == '(')
                    {
                        counter++;
                    }
                }
            }

            int index = GetLowOpIndex(expression);
            if (index != -1)
            {
                return new OpNode(
                    expression[index],
                    Compile(expression.Substring(0, index)),
                    Compile(expression.Substring(index + 1)));
            }

            return Getint(expression);
        }

        /// <summary>
        /// Define a class of node.
        /// </summary>
        private abstract class Node
        {
            /// <summary>
            /// Define evaluate function.
            /// </summary>
            /// <returns> return evaluate.</returns>
            public abstract double Eval();
        }

        /// <summary>
        /// This is the definition of node class.
        /// </summary>
        private class OpNode : Node
        {
            /// <summary>
            /// define a char.
            /// </summary>
            private readonly char myOp;

            /// <summary>
            /// define a node,left.
            /// </summary>
            private readonly Node myLeft;

            /// <summary>
            /// define a node,right.
            /// </summary>
            private readonly Node myRight;

            /// <summary>
            /// Initializes a new instance of the <see cref="OpNode"/> class.
            /// </summary>
            /// <param name="newOp">a char.</param>
            /// <param name="newLeft">a node,left.</param>
            /// <param name="newRight">a node, right.</param>
            public OpNode(char newOp, Node newLeft, Node newRight)
            {
                this.myOp = newOp;
                this.myLeft = newLeft;
                this.myRight = newRight;
            }

            /// <summary>
            /// A node that represents a binary operator and supports the addition and subtraction of operators.
            /// </summary>
            /// <returns>Output the calculated result.</returns>
            public override double Eval()
            {
                if (this.myOp == '+')
                {
                    return this.myLeft.Eval() + this.myRight.Eval();
                }
                else if (this.myOp == '-')
                {
                    return this.myLeft.Eval() - this.myRight.Eval();
                }
                else if (this.myOp == '*')
                {
                    return this.myLeft.Eval() * this.myRight.Eval();
                }
                else if (this.myOp == '/')
                {
                    if (this.myRight.Eval() != 0)
                    {
                        return this.myLeft.Eval() / this.myRight.Eval();
                    }
                    else
                    {
                        return double.NaN;
                    }
                }

                return double.NaN;
            }
        }

        /// <summary>
        /// Node representing a variable.
        /// </summary>
        private class VarNode : Node
        {
            /// <summary>
            /// define a string.
            /// </summary>
            private readonly string myVar;

            /// <summary>
            /// Define a dictionary called loop up.
            /// </summary>
            private Dictionary<string, double> lookup;

            /// <summary>
            /// Initializes a new instance of the <see cref="VarNode"/> class.
            /// </summary>
            /// <param name="varNode">define a string.</param>
            public VarNode(string varNode)
            {
                this.myVar = varNode;
                MyVars[this.myVar] = 0;
            }

            /// <summary>
            /// Call evaluate function again and put the resulting value into the dictionary.
            /// </summary>
            /// <returns>A dictionary value.</returns>
            public override double Eval()
            {
                this.lookup = MyVars;
                if (!this.lookup.ContainsKey(this.myVar))
                {
                    return double.NaN;
                }

                return this.lookup[this.myVar];
            }
        }

        /// <summary>
        /// Node representing a constant numerical value.
        /// </summary>
        private class ValueNode : Node
        {
            /// <summary>
            /// define a double value.
            /// </summary>
            private readonly double myValue;

            /// <summary>
            /// Initializes a new instance of the <see cref="ValueNode"/> class.
            /// </summary>
            /// <param name="newVal">a double value.</param>
            public ValueNode(double newVal)
            {
                this.myValue = newVal;
            }

            /// <summary>
            /// Call evaluate function again and get double value.
            /// </summary>
            /// <returns>return a double value.</returns>
            public override double Eval()
            {
                return this.myValue;
            }
        }
    }
}