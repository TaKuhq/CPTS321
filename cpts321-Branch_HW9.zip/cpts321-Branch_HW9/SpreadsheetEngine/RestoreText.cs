﻿// <copyright file="RestoreText.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace SpreadsheetEngine
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using CptS321;

    /// <summary>
    /// define the restore text.
    /// </summary>
    public class RestoreText : ICmdSystem
    {
        /// <summary>
        /// define a string my text.
        /// </summary>
        private string myText;

        /// <summary>
        /// define a string my name.
        /// </summary>
        private string myName;

        /// <summary>
        /// Initializes a new instance of the <see cref="RestoreText"/> class.
        /// </summary>
        /// <param name="cellText">call cell text.</param>
        /// <param name="cellName">call cell name.</param>
        public RestoreText(string cellText, string cellName)
        {
            this.myText = cellText;
            this.myName = cellName;
        }

        /// <summary>
        /// Restores old text for a cell.
        /// </summary>
        /// <param name="mySheet">event sheet.</param>
        /// <returns>old text class.</returns>
        public ICmdSystem Exec(Spreadsheet mySheet)
        {
            Cell cell = mySheet.GetCell(this.myName);

            string old = cell.Text;

            cell.Text = this.myText;

            RestoreText oldTextClass = new RestoreText(old, this.myName);

            return oldTextClass;
        }
    }
}
