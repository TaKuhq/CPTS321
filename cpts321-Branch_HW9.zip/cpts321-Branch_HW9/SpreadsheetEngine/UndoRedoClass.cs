﻿// <copyright file="UndoRedoClass.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace SpreadsheetEngine
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// undo redo class.
    /// </summary>
    public class UndoRedoClass
    {
        /// <summary>
        /// define a undo stack.
        /// </summary>
        private Stack<MultiCmds> myUndo = new Stack<MultiCmds>();

        /// <summary>
        /// define a redo stack.
        /// </summary>
        private Stack<MultiCmds> myRedo = new Stack<MultiCmds>();

        /// <summary>
        /// Gets a value indicating whether if undo stack empty, return false.
        /// </summary>
        public bool CanUndo
        {
            get
            {
                return this.myUndo.Count != 0;
            }
        }

        /// <summary>
        /// Gets a value indicating whether if redo stack empty, return false.
        /// </summary>
        public bool CanRedo
        {
            get
            {
                return this.myRedo.Count != 0;
            }
        }

        /// <summary>
        /// Gets if correct, return the action of this undo.
        /// </summary>
        public string UndoNext
        {
            get
            {
                if (this.CanUndo)
                {
                    return this.myUndo.Peek().MyName;
                }

                return string.Empty;
            }
        }

        /// <summary>
        /// Gets if correct, return the action of this redo.
        /// </summary>
        public string RedoNext
        {
            get
            {
                if (this.CanRedo)
                {
                    return this.myRedo.Peek().MyName;
                }

                return string.Empty;
            }
        }

        /// <summary>
        /// Adds an undo event to the undo stack.
        /// </summary>
        /// <param name="undo">an event.</param>
        public void AddUndos(MultiCmds undo)
        {
            this.myUndo.Push(undo);
            this.myRedo.Clear();
        }

        /// <summary>
        /// this function do undo push in redo stack.
        /// </summary>
        /// <param name="mySheet">push undo in redo.</param>
        public void Undo(Spreadsheet mySheet)
        {
            this.myRedo.Push(this.myUndo.Pop().Exec(mySheet));
        }

        /// <summary>
        /// this function do redo push in undo stack.
        /// </summary>
        /// <param name="mySheet">push redo in undo.</param>
        public void Redo(Spreadsheet mySheet)
        {
            this.myUndo.Push(this.myRedo.Pop().Exec(mySheet));
        }

        /// <summary>
        /// clear redo undo stack.
        /// </summary>
        public void Clear()
        {
            this.myUndo.Clear();
            this.myRedo.Clear();
        }
    }
}
