﻿// <copyright file="Spreadsheet.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace SpreadsheetEngine
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Xml;
    using System.Xml.Linq;
    using CptS321;

    /// <summary>
    /// spreadsheet function.
    /// </summary>
    public class Spreadsheet
    {
        /// <summary>
        /// public data members.
        /// </summary>
#pragma warning disable SA1401 // Fields should be private
        public Cell[,] MyCells;
#pragma warning restore SA1401 // Fields should be private

        /// <summary>
        /// create undo redo class.
        /// </summary>
#pragma warning disable SA1401 // Fields should be private
        public UndoRedoClass UndoRedo = new UndoRedoClass();
#pragma warning restore SA1401 // Fields should be private

        /// <summary>
        /// create a dictionary.
        /// </summary>
        private Dictionary<string, HashSet<string>> depDict;

        /// <summary>
        /// Initializes a new instance of the <see cref="Spreadsheet"/> class.
        /// </summary>
        /// <param name="rowIndex">The number of rows.</param>
        /// <param name="columnIndex">The number of columns.</param>
        public Spreadsheet(int rowIndex, int columnIndex)
        {
            this.MyCells = new Cell[rowIndex, columnIndex];

            this.depDict = new Dictionary<string, HashSet<string>>();

            for (int x = 0; x < rowIndex; x++)
            {
                for (int y = 0; y < columnIndex; y++)
                {
                    this.MyCells[x, y] = new CreateACell(x, y);
                    this.MyCells[x, y].PropertyChanged += this.ChangeCell;
                }
            }
        }

        /// <summary>
        /// create a cells, come up with a design here that actually allows the spreadsheet.
        /// </summary>
        public event PropertyChangedEventHandler CellPropertyChanged;

        /// <summary>
        /// Gets row count.
        /// </summary>
        public int RowCount
        {
            get { return this.MyCells.GetLength(0); }
        }

        /// <summary>
        /// Gets column count.
        /// </summary>
        public int ColumnCount
        {
            get { return this.MyCells.GetLength(1); }
        }

        /// <summary>
        /// get a cell by using.
        /// </summary>
        /// <param name="expression">a string.</param>
        /// <returns>return cell.</returns>
        public Cell GetCell(string expression)
        {
            char letter = expression[0];
            Cell result;

            if (char.IsLetter(letter) == false)
            {
                return null;
            }

            if (short.TryParse(expression.Substring(1), out short number) == false)
            {
                return null;
            }

            try
            {
                result = this.GetCell(number - 1, letter - 'A');
            }
            catch
            {
                return null;
            }

            return result;
        }

        /// <summary>
        /// change the property.
        /// </summary>
        /// <param name="sender">The parameters of the cell.</param>
        /// <param name="e">The parameter is not used.</param>
        public void ChangeCell(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "Text")
            {
                CreateACell tmpCell = sender as CreateACell;
                this.RemoveDep(tmpCell.Name);

                if (tmpCell.Text != string.Empty && tmpCell.Text[0] == '=')
                {
                    ExpressionTree exp = new ExpressionTree(tmpCell.Text.Substring(1));
                    this.MakeDep(tmpCell.Name, exp.GetAllVariables());
                }

                this.Eval(sender as Cell);
            }
            else if (e.PropertyName == "BGColor")
            {
                this.CellPropertyChanged(sender, new PropertyChangedEventArgs("BGColor"));
            }
        }

        /// <summary>
        /// get cell from given row and column.
        /// </summary>
        /// <param name="rowIndex">The number of rows.</param>
        /// <param name="columnIndex">The number of columns.</param>
        /// <returns>a cell.</returns>
        public Cell GetCell(int rowIndex, int columnIndex)
        {
            return this.MyCells[rowIndex, columnIndex];
        }

        /// <summary>
        /// save file.
        /// </summary>
        /// <param name="outfile">file name.</param>
        public void Save(Stream outfile)
        {
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;

            XmlWriter writeXml = XmlWriter.Create(outfile, settings);

            writeXml.WriteStartElement("spreadsheet");

            foreach (Cell m_cell in this.MyCells)
            {
                if (m_cell.Text != string.Empty || m_cell.Value != string.Empty || m_cell.BGColor != 4294967295)
                {
                    writeXml.WriteStartElement("cell");
                    writeXml.WriteAttributeString("name", m_cell.Name);
                    writeXml.WriteElementString("bgcolor", m_cell.BGColor.ToString("x8"));
                    writeXml.WriteElementString("text", m_cell.Text.ToString());
                    writeXml.WriteEndElement();
                }
            }

            writeXml.WriteEndElement();
            writeXml.Close();
        }

        /// <summary>
        /// load file.
        /// </summary>
        /// <param name="infile">file name.</param>
        public void Load(Stream infile)
        {
            XDocument inf = XDocument.Load(infile);

            foreach (XElement label in inf.Root.Elements("cell"))
            {
                Cell m_cell = this.GetCell(label.Attribute("name").Value);

                if (label.Element("text") != null)
                {
                    m_cell.Text = label.Element("text").Value.ToString();
                }

                if (label.Element("bgcolor") != null)
                {
                    m_cell.BGColor = uint.Parse(label.Element("bgcolor").Value, System.Globalization.NumberStyles.HexNumber);
                }
            }
        }

        /// <summary>
        /// set the value to empty.
        /// </summary>
        /// <param name="myCell">new cell.</param>
        /// <param name="cell">return a void.</param>
        private void SetEmpty(CreateACell myCell, Cell cell)
        {
            myCell.SetValue(string.Empty);
            this.CellPropertyChanged(cell, new PropertyChangedEventArgs("Value"));
        }

        /// <summary>
        /// set value.
        /// </summary>
        /// <param name="myCell">new cell.</param>
        /// <param name="cell">return a void.</param>
        private void SetExp(CreateACell myCell, Cell cell)
        {
            ExpressionTree exptree = new ExpressionTree(myCell.Text.Substring(1));
            string[] variables = exptree.GetAllVariables();
            foreach (string variableName in variables)
            {
                Cell variableCell = this.GetCell(variableName);
                double value;

                if (string.IsNullOrEmpty(variableCell.Value))
                {
                    exptree.SetVariable(variableCell.Name, 0);
                }
                else if (!double.TryParse(variableCell.Value, out value))
                {
                    exptree.SetVariable(variableName, 0);
                }
                else
                {
                    exptree.SetVariable(variableName, value);
                }
            }

            myCell.SetValue(exptree.Evaluate().ToString());
            this.CellPropertyChanged(cell, new PropertyChangedEventArgs("Value"));
        }

        /// <summary>
        /// set value in text.
        /// </summary>
        /// <param name="myCell">new cell.</param>
        /// <param name="cell">return a void.</param>
        private void SetText(CreateACell myCell, Cell cell)
        {
            myCell.SetValue(myCell.Text);
            this.CellPropertyChanged(cell, new PropertyChangedEventArgs("Value"));
        }

        /// <summary>
        /// Create the format of the cell.
        /// </summary>
        /// <param name="cell">return empty.</param>
        private void Eval(Cell cell)
        {
            CreateACell myCells = cell as CreateACell;

            if (string.IsNullOrEmpty(myCells.Text))
            {
                this.SetEmpty(myCells, cell);
            }
            else if (myCells.Text[0] == '=' && myCells.Text.Length >= 3)
            {
                this.SetExp(myCells, cell);
            }
            else
            {
                this.SetText(myCells, cell);
            }

            if (this.depDict.ContainsKey(myCells.Name))
            {
                foreach (var dependentCell in this.depDict[myCells.Name])
                {
                    this.Eval(dependentCell);
                }
            }
        }

        /// <summary>
        /// call get cell function.
        /// </summary>
        /// <param name="expression">a string.</param>
        private void Eval(string expression)
        {
            this.Eval(this.GetCell(expression));
        }

        /// <summary>
        /// Removes all dependencies from the cell name.
        /// </summary>
        /// <param name="cellName">the cell names.</param>
        private void RemoveDep(string cellName)
        {
            List<string> dependenciesList = new List<string>();

            foreach (string key in this.depDict.Keys)
            {
                if (this.depDict[key].Contains(cellName))
                {
                    dependenciesList.Add(key);
                }
            }

            foreach (string key in dependenciesList)
            {
                HashSet<string> hashset = this.depDict[key];
                if (hashset.Contains(cellName))
                {
                    hashset.Remove(cellName);
                }
            }
        }

        /// <summary>
        /// Make all dependencies for the table.
        /// </summary>
        /// <param name="cellName">a string.</param>
        /// <param name="variablesUsed">a table.</param>
        private void MakeDep(string cellName, string[] variablesUsed)
        {
            for (int i = 0; i < variablesUsed.Length; i++)
            {
                if (this.depDict.ContainsKey(variablesUsed[i]) == false)
                {
                    this.depDict[variablesUsed[i]] = new HashSet<string>();
                }

                this.depDict[variablesUsed[i]].Add(cellName);
            }
        }

        /// <summary>
        /// create a cell.
        /// </summary>
        private class CreateACell : Cell
        {
            /// <summary>
            /// Initializes a new instance of the <see cref="CreateACell"/> class.
            /// </summary>
            /// <param name="rowIndex">row index.</param>
            /// <param name="columnIndex">column index.</param>
            public CreateACell(int rowIndex, int columnIndex)
                : base(rowIndex, columnIndex)
            {
            }

            /// <summary>
            /// put value in my values.
            /// </summary>
            /// <param name="value">a string.</param>
            public void SetValue(string value)
            {
                this.myValue = value;
            }
        }
    }
}
