﻿// <copyright file="ICmdSystem.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>

namespace SpreadsheetEngine
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// call undo redo.
    /// </summary>
    public interface ICmdSystem
    {
        /// <summary>
        /// define my sheet.
        /// </summary>
        /// <param name="mySheet">call by spreadsheet.</param>
        /// <returns>return execute.</returns>
        ICmdSystem Exec(Spreadsheet mySheet);
    }

    /// <summary>
    /// define the function.
    /// </summary>
    public class MultiCmds
    {
        /// <summary>
        /// define a public string.
        /// </summary>
#pragma warning disable SA1401 // Fields should be private
        public string MyName;
#pragma warning restore SA1401 // Fields should be private

        /// <summary>
        /// define a private interface.
        /// </summary>
        private ICmdSystem[] myCmd;

        /// <summary>
        /// Initializes a new instance of the <see cref="MultiCmds"/> class.
        /// </summary>
        public MultiCmds()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MultiCmds"/> class.
        /// </summary>
        /// <param name="cmds">a interface.</param>
        /// <param name="name">a string.</param>
        public MultiCmds(ICmdSystem[] cmds, string name)
        {
            this.myCmd = cmds;
            this.MyName = name;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="MultiCmds"/> class.
        /// </summary>
        /// <param name="cmds">a interface.</param>
        /// <param name="name">a string.</param>
        public MultiCmds(List<ICmdSystem> cmds, string name)
        {
            this.myCmd = cmds.ToArray();
            this.MyName = name;
        }

        /// <summary>
        /// calls each one in the cmd system.
        /// </summary>
        /// <param name="sheet">sheet value.</param>
        /// <returns>class cmd system.</returns>
        public MultiCmds Exec(Spreadsheet sheet)
        {
            List<ICmdSystem> cmd_list = new List<ICmdSystem>();

            foreach (ICmdSystem cmd in this.myCmd)
            {
                ICmdSystem doCmd = cmd.Exec(sheet);

                cmd_list.Add(doCmd);
            }

            MultiCmds mulcmds = new MultiCmds(cmd_list.ToArray(), this.MyName);

            return mulcmds;
        }
    }
}
