﻿//-----------------------------------------------------------------------
// <copyright file="ExpressionTree.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace CptS321
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    /// <summary>
    /// This is the definition of ExpressionTree class.
    /// </summary>
    public class ExpressionTree
    {
        /// <summary>
        /// a member dictionary.
        /// </summary>
        private static readonly Dictionary<string, double> MyVars = new Dictionary<string, double>();

        /// <summary>
        /// define a node, my root.
        /// </summary>
        private readonly Node myRoot;

        /// <summary>
        /// Initializes a new instance of the <see cref="ExpressionTree"/> class.
        /// </summary>
        public ExpressionTree()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ExpressionTree"/> class.
        /// </summary>
        /// <param name="expression">String name.</param>
        public ExpressionTree(string expression)
        {
            this.myRoot = Compile(expression);
        }

        /// <summary>
        /// Test helper function, get dictionary value.
        /// </summary>
        /// <param name="a">A string value.</param>
        /// <returns>A double number.</returns>
        public double Lookup(string a)
        {
            return MyVars[a];
        }

        /// <summary>
        /// Sets the specified variable within the ExpressionTree variables dictionary.
        /// </summary>
        /// <param name="variableName">A string name.</param>
        /// <param name="variableValue">A double value.</param>
        public void SetVariable(string variableName, double variableValue)
        {
            MyVars[variableName] = variableValue;
        }

        /// <summary>
        /// Implement this method with no parameters that evaluates the expression to a double value.
        /// </summary>
        /// <returns>A double value.</returns>
        public double Evaluate()
        {
            if (this.myRoot != null)
            {
                return this.myRoot.Eval();
            }
            else
            {
                return double.NaN;
            }
        }

        /// <summary>
        /// This function does is it makes a tree.
        /// </summary>
        /// <param name="expression">A string name.</param>
        /// <returns>cant return a public type.</returns>
        private static Node Compile(string expression)
        {
            for (int i = expression.Length - 1; i >= 0; i--)
            {
                switch (expression[i])
                {
                    case '+':
                    case '-':
                        return new OpNode(
                            expression[i],
                            Compile(expression.Substring(0, i)),
                            Compile(expression.Substring(i + 1)));
                }
            }

            if (double.TryParse(expression, out double result))
            {
                return new ValueNode(result);
            }

            return new VarNode(expression);
        }

        /// <summary>
        /// Define a class of node.
        /// </summary>
        private abstract class Node
        {
            /// <summary>
            /// Define evaluate function.
            /// </summary>
            /// <returns> return evaluate.</returns>
            public abstract double Eval();
        }

        /// <summary>
        /// This is the definition of node class.
        /// </summary>
        private class OpNode : Node
        {
            /// <summary>
            /// define a char.
            /// </summary>
            private readonly char myOp;

            /// <summary>
            /// define a node,left.
            /// </summary>
            private readonly Node myLeft;

            /// <summary>
            /// define a node,right.
            /// </summary>
            private readonly Node myRight;

            /// <summary>
            /// Initializes a new instance of the <see cref="OpNode"/> class.
            /// </summary>
            /// <param name="newOp">a char.</param>
            /// <param name="newLeft">a node,left.</param>
            /// <param name="newRight">a node, right.</param>
            public OpNode(char newOp, Node newLeft, Node newRight)
            {
                this.myOp = newOp;
                this.myLeft = newLeft;
                this.myRight = newRight;
            }

            /// <summary>
            /// A node that represents a binary operator and supports the addition and subtraction of operators.
            /// </summary>
            /// <returns>Output the calculated result.</returns>
            public override double Eval()
            {
                if (this.myOp == '+')
                {
                    return this.myLeft.Eval() + this.myRight.Eval();
                }
                else if (this.myOp == '-')
                {
                    return this.myLeft.Eval() - this.myRight.Eval();
                }
                else
                {
                    return double.NaN;
                }
            }
        }

        /// <summary>
        /// Node representing a variable.
        /// </summary>
        private class VarNode : Node
        {
            /// <summary>
            /// define a string.
            /// </summary>
            private readonly string myVar;

            /// <summary>
            /// Initializes a new instance of the <see cref="VarNode"/> class.
            /// </summary>
            /// <param name="varNode">define a string.</param>
            public VarNode(string varNode)
            {
                this.myVar = varNode;
                MyVars[this.myVar] = 0.0;
            }

            /// <summary>
            /// Call evaluate function again and put the resulting value into the dictionary.
            /// </summary>
            /// <returns>A dictionary value.</returns>
            public override double Eval()
            {
                return MyVars[this.myVar];
            }
        }

        /// <summary>
        /// Node representing a constant numerical value.
        /// </summary>
        private class ValueNode : Node
        {
            /// <summary>
            /// define a double value.
            /// </summary>
            private readonly double myValue;

            /// <summary>
            /// Initializes a new instance of the <see cref="ValueNode"/> class.
            /// </summary>
            /// <param name="newVal">a double value.</param>
            public ValueNode(double newVal)
            {
                this.myValue = newVal;
            }

            /// <summary>
            /// Call evaluate function again and get double value.
            /// </summary>
            /// <returns>return a double value.</returns>
            public override double Eval()
            {
                return this.myValue;
            }
        }
    }
}
