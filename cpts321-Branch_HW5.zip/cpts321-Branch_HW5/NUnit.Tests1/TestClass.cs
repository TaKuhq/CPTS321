﻿//-----------------------------------------------------------------------
// <copyright file="TestClass.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace NUnit.Tests1
{
    using System.Collections;
    using System.Collections.Generic;
    using CptS321;
    using NUnit.Framework;

    /// <summary>
    /// Test cases, three in all.
    /// </summary>
    [TestFixture]
    public class TestClass
    {
        /// <summary>
        /// This is the first test that check expression tree.
        /// </summary>
        [Test]
        public void TestMethod()
        {
            string a = "CptS321.ExpressionTree";
            ExpressionTree sting = new ExpressionTree(a);
            Assert.That(sting.ToString, Is.EqualTo(a), "Some useful error message");
        }

        /// <summary>
        /// This is the second test case.Test whether the output result of SetVariable is a string.
        /// </summary>
        [Test]
        public void TestMethod1()
        {
            string a = "hello";
            double b = 27.0;
            ExpressionTree sting = new ExpressionTree("hello + world");
            sting.SetVariable(a, b);
            Assert.That(sting.Lookup(a), Is.EqualTo(b), "Some useful error message");
        }

        /// <summary>
        /// This is the third test case,test whether the output result of SetVariable is a double number.
        /// </summary>
        [Test]
        public void TestMethod2()
        {
            string a = "world";
            double b = 32.1;
            ExpressionTree sting = new ExpressionTree("hello + world");
            sting.SetVariable(a, b);
            Assert.That(sting.Lookup(a), Is.EqualTo(b), "Some useful error message");
        }
    }
}
