﻿//-----------------------------------------------------------------------
// <copyright file="Program.cs" company="PlaceholderCompany">
// Copyright (c) PlaceholderCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace HW5
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using CptS321;

    /// <summary>
    /// define program class.
    /// </summary>
    public class Program
    {
        /// <summary>
        /// Define menu format.
        /// </summary>
        /// <param name="args">Invalid parameter.</param>
        private static void Main(string[] args)
        {
            if (args is null)
            {
                throw new ArgumentNullException(nameof(args));
            }

            ExpressionTree et = new ExpressionTree();
            string expression = string.Empty;
            while (true)
            {
                Console.WriteLine("Menu (current expression=\"" + expression + "\")");
                Console.WriteLine("  1 = Enter a new expression");
                Console.WriteLine("  2 = Set a variable value");
                Console.WriteLine("  3 = Evaluate tree");
                Console.WriteLine("  4 = Quit");
                string input = Console.ReadLine();
                switch (input)
                {
                    case "1":
                        Console.Write("Enter new expression: ");
                        expression = Console.ReadLine();
                        et = new ExpressionTree(expression);
                        break;
                    case "2":
                        Console.Write("Enter variable name: ");
                        string varName = Console.ReadLine();
                        Console.Write("Enter variable value: ");
                        string varStr = Console.ReadLine();
                        double varValue = Convert.ToDouble(varStr);
                        et.SetVariable(varName, varValue);
                        break;
                    case "3":
                        Console.WriteLine("Answer = " + et.Evaluate());
                        break;
                    case "4":
                        Console.WriteLine("Done");
                        System.Environment.Exit(0);
                        break;
                    default:
                        break;
                }
            }
        }
    }
}
